var bg;
var p1;
var state=0;
var fenceimg;
var demonwalk;
var playerwalk
function preload(){
  bg=loadImage("bg1.png");
  fenceimg=loadImage("ground&houses_bg.png")
  demonwalk=loadAnimation("demon/Walk1.png","demon/Walk2.png","demon/Walk3.png","demon/Walk4.png","demon/Walk5.png","demon/Walk6.png")
  playerwalk=loadAnimation("player/run1.png","player/run2.png","player/run3.png","player/run4.png","player/run5.png","player/run6.png","player/run7.png","player/run8.png","player/run9.png")
}
function setup() {
  createCanvas(displayWidth-50,displayHeight-180);
  p1=createSprite(50,200,50,50);
  p1.addAnimation("walk",playerwalk);
  p1.scale=0.2;

  fence=createSprite(displayWidth/2,displayHeight-100,displayWidth,150);
  fence.addImage(fenceimg);
  fence.visible=false;
 
  demon=createSprite(displayWidth-50,displayHeight-180);
 demon.addAnimation("walk",demonwalk);
 demon.visible=false

 
}

function draw() {
  background(bg);  
  if(keyWentDown("RIGHT_ARROW")){
    p1.velocityX=15;
  }
  if(keyWentUp("RIGHT_ARROW")){
    p1.velocityX=0;
  }
  if(p1.x>displayWidth-50 && state===0 ){
    p1.x=50;
    bg=loadImage("bg2.jpg");
    state++;

  }
  if(p1.x>displayWidth-50 && state===1 ){
    p1.x=50;
  bg=loadImage("clouds1.png");
 fence.visible=true;
 demon.visible=true;
 demon.velocityX=-2;
  }
  drawSprites();
}